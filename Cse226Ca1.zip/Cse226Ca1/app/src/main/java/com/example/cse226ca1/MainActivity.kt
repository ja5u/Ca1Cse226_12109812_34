package com.example.cse226ca1

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    private lateinit var btn: Button
    private lateinit var img: ImageView
    private lateinit var vid: VideoView
    private lateinit var e: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn = findViewById(R.id.sub)
        img = findViewById(R.id.imgv)
        vid = findViewById(R.id.vid)
        e = findViewById(R.id.url)

        btn.setOnClickListener {
            lifecycleScope.launch(Dispatchers.IO) {
                val url = e.text.toString()
                val data = fetchData(url)

                withContext(Dispatchers.Main) {
                    if (data is ByteArray) {
                        val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
                        img.setImageBitmap(bitmap)
                        img.visibility = View.VISIBLE
                        vid.visibility = View.GONE
                        Toast.makeText(this@MainActivity,"Successfully Image Download",Toast.LENGTH_LONG).show()
                    } else if (data is File) {
                        img.visibility = View.GONE
                        vid.visibility = View.VISIBLE
                        vid.setVideoURI(Uri.fromFile(data))
                        vid.start()
                        Toast.makeText(this@MainActivity,"Successfully Video Download",Toast.LENGTH_LONG).show()
                    } else {
                        Log.e("MainActivity", "Failed to fetch data.")
                    }
                }
            }
        }
    }

    private suspend fun fetchData(url: String): Any? {
        return withContext(Dispatchers.IO) {
            try {
                // Improved check for image and video extensions
                when {
                    url.endsWith(".jpg", true) || url.endsWith(".png", true) -> {
                        // Fetch image
                        val client = OkHttpClient()
                        val request = Request.Builder().url(url).build()
                        val response = client.newCall(request).execute()

                        if (response.isSuccessful) {
                            response.body?.bytes()
                        } else {
                            Log.e("FetchData", "Image fetch failed with code: ${response.code}")
                            Toast.makeText(this@MainActivity,"Image fetch failed with code: ${response.code}",Toast.LENGTH_LONG).show()
                            null
                        }
                    }
                    url.endsWith(".mp4", true) || url.endsWith(".mkv", true) -> {
                        // Fetch video
                        val connection = URL(url).openConnection() as HttpURLConnection
                        connection.requestMethod = "GET"
                        connection.connect()

                        if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                            val input = connection.inputStream
                            val file = File(cacheDir, "d_video.mp4")
                            FileOutputStream(file).use { outputStream ->
                                input.copyTo(outputStream)
                            }
                            input.close()
                            file

                        } else {
                            Toast.makeText(this@MainActivity,"Video fetch failed with code: ${connection.responseCode}",Toast.LENGTH_LONG).show()
                            null
                        }
                    }
                    else -> {
                        Log.e("FetchData", "Unsupported file format.")

                        null
                    }
                }
            } catch (e: Exception) {
                Log.e("FetchData", "Exception during fetch", e)
                Toast.makeText(this@MainActivity,"Exception during fetch",Toast.LENGTH_LONG).show()
                null
            }
        }
    }
}
